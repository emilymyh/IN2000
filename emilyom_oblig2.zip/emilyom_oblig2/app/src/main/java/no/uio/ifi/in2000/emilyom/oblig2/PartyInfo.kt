package no.uio.ifi.in2000.emilyom.oblig2

import java.net.URL
import kotlinx.serialization.Serializable

@Serializable
data class PartyInfo(val parties : String,
                     val id : String,
                     val name : String,
                     val img: String,
                     val color : String,
                     val description: String)

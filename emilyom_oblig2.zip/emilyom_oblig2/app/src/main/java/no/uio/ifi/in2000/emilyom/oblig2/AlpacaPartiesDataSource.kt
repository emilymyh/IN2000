package no.uio.ifi.in2000.emilyom.oblig2

import io.ktor.client.HttpClient
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.request.get
import kotlinx.serialization.json.Json
import io.ktor.client.call.body

import io.ktor.serialization.kotlinx.json.json




class AlpacaPartiesDataSource {
    private val ktorHttpClient = HttpClient {
        install(ContentNegotiation) {
            json(Json { ignoreUnknownKeys = true }) // Ignorerer ukjente felter
        }
    }

    suspend fun getAlpacaPartiesResponse(): List<PartyInfo> {
        return try {
            ktorHttpClient.get("https://in2000-proxy.ifi.uio.no/alpacaapi/v2/alpacaparties").body()
        } catch (e: Exception) {
            // Returnerer en tom liste hvis API-kallet feiler
            emptyList()
        }
    }
}


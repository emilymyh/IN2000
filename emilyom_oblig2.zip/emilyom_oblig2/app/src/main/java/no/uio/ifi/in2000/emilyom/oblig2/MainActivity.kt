package no.uio.ifi.in2000.emilyom.oblig2

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import no.uio.ifi.in2000.emilyom.oblig2.ui.theme.Emilyom_oblig2Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Emilyom_oblig2Theme {
                homeScreen(
                    viewModel = viewModel())
            }
        }
    }
}

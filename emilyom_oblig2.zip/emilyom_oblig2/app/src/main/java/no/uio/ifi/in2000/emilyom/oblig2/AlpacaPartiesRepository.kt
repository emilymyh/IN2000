package no.uio.ifi.in2000.emilyom.oblig2



open class AlpacaPartiesRepository(private val alpacaPartiesDataSource: AlpacaPartiesDataSource) {
    open suspend fun getAlpacaParties(): List<PartyInfo> {
        return alpacaPartiesDataSource.getAlpacaPartiesResponse()
    }
}
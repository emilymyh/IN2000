package no.uio.ifi.in2000.emilyom.oblig2


import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope

import kotlinx.coroutines.launch
import java.net.URL


class AlpacaPartiesViewModel(private val repository: AlpacaPartiesRepository) : ViewModel() {

    var partyList by mutableStateOf<List<PartyInfo>>(emptyList())
        private set

    init {
        fetchParties()
    }

    fun fetchParties() {
        viewModelScope.launch {
            partyList = repository.getAlpacaParties()
        }
    }
}
